public class Bounce {
   public static void main(String[] args) {
      
      
      
      
   }
}